const math = require('math')

var loans = []

const loan1 = {
        id: 0,
        customerName: "Tony",
        phoneNumber: 1098792224,
        address: "Mesa",
        monthlyPayment:50,
        interest: 5,
        loanTermYears: 4,
        loanType: "Student Loan",
        description: "Educational Loan",
        calculatedLoanAmount: function(){
            return this.monthlyPayment*((1+this.interest)**this.loanTermYears)*((((1+this.interest)**this.loanTermYears)-1)/this.interest)
        }

    }

const loan2 = {
        id: 1,
        customerName: "Thor",
        phoneNumber: 1098746329,
        address: "Tempe",
        monthlyPayment: 80,
        interest: 5,
        loanTermYears: 3,
        loanType: "Personal Loan",
        description: "Loan for a Car",
        calculatedLoanAmount: function(){
            return this.monthlyPayment*((1+this.interest)**this.loanTermYears)*((((1+this.interest)**this.loanTermYears)-1)/this.interest)
        }
    }

const loan3 = {
        id: 2,
        customerName: "Bruce",
        phoneNumber: 1094312329,
        address: "Charlotte",
        monthlyPayment: 92.5,
        interest: 6,
        loanTermYears: 4,
        loanType: "Auto Loan",
        description: "The Auto Loan",
        calculatedLoanAmount: function(){
            return this.monthlyPayment*((1+this.interest)**this.loanTermYears)*((((1+this.interest)**this.loanTermYears)-1)/this.interest)
        }
    }

const loan4 = {
        id: 3,
        customerName: "Steve",
        phoneNumber: 1998746329,
        address: "New York",
        monthlyPayment: 500,
        interest: 10,
        loanTermYears: 2,
        loanType: "Personal Loan",
        description: "Loan for a House",
        calculatedLoanAmount: function(){
            return this.monthlyPayment*((1+this.interest)**this.loanTermYears)*((((1+this.interest)**this.loanTermYears)-1)/this.interest)
        }
    }

const loan5 = {
        id: 4,
        customerName: "Scarlett",
        phoneNumber: 3458746329,
        address: "London",
        monthlyPayment: 670,
        interest: 5,
        loanTermYears: 2,
        loanType: "Mortage Loan",
        description: "Loan for Mortage",
        calculatedLoanAmount: function(){
            return this.monthlyPayment*((1+this.interest)**this.loanTermYears)*((((1+this.interest)**this.loanTermYears)-1)/this.interest)
        }
    }              

loans.push(loan1)
loans.push(loan2)
loans.push(loan3)
loans.push(loan4)
loans.push(loan5)    

// console.log(loans)

loans.forEach((item)=> console.log(`Loan Amount:${item.calculatedLoanAmount()}`));

let loanAmtArray = loans.map(loanAmt => loanAmt.calculatedLoanAmount());

//console.log(loanAmtArray)

const sum = loanAmtArray.reduce((accumulator, value) => {
    return accumulator + value;
  }, );
  
  console.log(`The total sum of loans = ${sum}`);


// loans.forEach(loan => {
//     for (let key in loan) {
//         console.log(`${key}: ${loan[key]}`);
//     }
// });

// let idarray = loans.map(ids => ids.id);

// console.log(idarray)



// function loanAmountCalculator(monthlyPayment, interest, loanTermYears){
//     const loanAmount = loan.monthlyPayment*((1+loan.interest)**loan.loanTermYears)*((((1+loan.interest)**loan.loanTermYears)-1)/loan.interest)
//     return loanAmount
// } 

// console.log(loanAmountCalculator(loan))