SELECT DB_NAME();
CREATE TABLE Samkrish
(
   Userid INT NOT NULL PRIMARY KEY, -- primary key column
   UName [NVARCHAR](50) NOT NULL,
    Address [NVARCHAR](50) NOT NULL
);

INSERT into Samkrish VALUES 
(1 , 'Deshraj','Peso'),
(2,'Parmeet','Apollo'),
(3,'Alifa','Omina');

Select *from Samkrish;

UPDATE samkrish
SET
    Address = 'Scotsdale'
    
WHERE 	Userid =1;

DELETE from Samkrish 
where Userid =3;

