SELECT DB_NAME();
Select * FROM SalesLT.Customer;

SELECT ProductID , ProductNumber , ListPrice
FROM SalesLT.Product
INNER JOIN SalesLT.ProductCategory
ON SalesLT.Product.ProductCategoryID = SalesLT.ProductCategory.ProductCategoryID;
